<?php
$db = new PDO('mysql:host=185.141.34.56;dbname=vetpet;charset=utf8mb4', 'vetpet', 'cETNNAHT7YNL*--');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>